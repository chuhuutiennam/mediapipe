"""Worker class: MediaPipe ImageSegmenter lifecycle and per-stream gRPC handler."""
import io
import logging
import math
import time
from queue import Empty, SimpleQueue

import grpc
import mediapipe as mp
import numpy as np
from PIL import Image

from mediapipe_video.codec import encode_rle, threshold_mask
from mediapipe_video.config import MediaPipeConfig, SegmentationConfig
from mediapipe_video.contract import pb

logger = logging.getLogger(__name__)


class Worker:
    def __init__(self, mp_config: MediaPipeConfig, seg_config: SegmentationConfig | None = None):
        self.base_options = mp.tasks.BaseOptions(
            model_asset_path=str(mp_config.model),
            delegate=mp.tasks.BaseOptions.Delegate[mp_config.delegate.upper()],
        )
        self.foreground_index = mp_config.foreground_index
        self.result_timeout = mp_config.result_timeout_secs
        self.seg_config = seg_config or SegmentationConfig()
        # Validate model and delegate before accepting any gRPC calls.
        # LIVE_STREAM requires a callback even for this startup probe.
        with self.create_segmenter(lambda result, image, timestamp_ms: None):
            pass

    def create_segmenter(self, callback):
        return mp.tasks.vision.ImageSegmenter.create_from_options(
            mp.tasks.vision.ImageSegmenterOptions(
                base_options=self.base_options,
                running_mode=mp.tasks.vision.RunningMode.LIVE_STREAM,
                output_confidence_masks=True,
                output_category_mask=False,
                result_callback=callback,
            )
        )

    def foreground_mask(self, result, threshold):
        probabilities = result.confidence_masks or []
        index = self.foreground_index
        if index is None:
            # SelfieSegmenter: one person plane; binary models: background/person.
            if len(probabilities) not in (1, 2):
                raise ValueError("expected 1 or 2 confidence masks; multiclass model requires --foreground-index")
            index = 0 if len(probabilities) == 1 else 1
        if not 0 <= index < len(probabilities):
            raise ValueError("foreground-index outside confidence masks")
        # Threshold inside the callback: numpy_view() borrows MediaPipe memory.
        return threshold_mask(probabilities[index].numpy_view(), threshold)

    def wait_for_result(self, results, timestamp_ms, context):
        deadline = time.monotonic() + self.result_timeout
        while True:
            if not context.is_active():
                context.abort(grpc.StatusCode.CANCELLED, "stream cancelled while waiting for segmentation")
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                # End this stream so a late callback cannot be matched to another frame.
                context.abort(grpc.StatusCode.DEADLINE_EXCEEDED, "timed out waiting for MediaPipe callback")
            try:
                timestamp, foreground, error = results.get(timeout=min(self.seg_config.poll_interval_secs, remaining))
            except Empty:
                continue
            if timestamp != timestamp_ms:
                context.abort(grpc.StatusCode.INTERNAL, "MediaPipe callback timestamp does not match frame")
            if error is not None:
                raise ValueError(error)
            return foreground

    def Segment(self, requests, context):
        first = next(requests, None)
        if first is None or first.WhichOneof("payload") != "config" or not first.session_id or first.is_eos:
            context.abort(grpc.StatusCode.INVALID_ARGUMENT, "first message must contain config and session_id")
        config = first.config
        if config.effect_type not in self.seg_config.allowed_effect_types:
            context.abort(grpc.StatusCode.INVALID_ARGUMENT, "unsupported effect_type")
        threshold = config.threshold or self.seg_config.default_threshold
        if not math.isfinite(threshold) or not 0 <= threshold <= 1:
            context.abort(grpc.StatusCode.INVALID_ARGUMENT, "threshold must be in [0,1]")
        max_dim = self.seg_config.max_inference_dim
        if not (0 < config.inference_width <= max_dim and 0 < config.inference_height <= max_dim):
            context.abort(grpc.StatusCode.INVALID_ARGUMENT, f"inference dimensions must be in 1..{max_dim}")
        results = SimpleQueue()

        def on_result(result, image, timestamp_ms):
            try:
                foreground = self.foreground_mask(result, threshold)
                results.put((timestamp_ms, foreground, None))
            except Exception as exc:
                # Never let a Python callback exception strand the gRPC consumer.
                results.put((timestamp_ms, None, str(exc)))

        with self.create_segmenter(on_result) as segmenter:
            last_timestamp = -1
            for req in requests:
                if not context.is_active():
                    return
                if req.session_id != first.session_id or req.stream_id != first.stream_id:
                    context.abort(grpc.StatusCode.INVALID_ARGUMENT, "session_id/stream_id changed within stream")
                payload = req.WhichOneof("payload")
                if req.is_eos and payload is None:
                    return
                if payload != "frame":
                    context.abort(grpc.StatusCode.INVALID_ARGUMENT, "expected frame after config")
                frame = req.frame
                mask = pb.VideoMask(frame_id=frame.frame_id, rtp_timestamp=frame.rtp_timestamp)
                started = time.perf_counter()
                try:
                    if frame.encoding != "jpeg":
                        raise ValueError("encoding must be jpeg")
                    if frame.timestamp_ms <= last_timestamp:
                        raise ValueError("timestamp_ms must increase within a stream")
                    with Image.open(io.BytesIO(frame.image_data)) as image:
                        if image.format != "JPEG" or image.size != (config.inference_width, config.inference_height):
                            raise ValueError("JPEG dimensions do not match config")
                        rgb = np.ascontiguousarray(image.convert("RGB"))
                    image = mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb)
                    # One in-flight image per stream preserves one mask per frame:
                    # LIVE_STREAM may silently drop images submitted while busy.
                    segmenter.segment_async(image, frame.timestamp_ms)
                    last_timestamp = frame.timestamp_ms
                    foreground = self.wait_for_result(results, frame.timestamp_ms, context)
                    mask.mask_height, mask.mask_width = foreground.shape
                    mask.rle_counts.extend(encode_rle(foreground))
                    mask.status = "ok"
                except (ValueError, OSError, RuntimeError) as exc:
                    mask.status, mask.error_message = "error", str(exc)
                mask.latency_ms = (time.perf_counter() - started) * 1000
                if mask.status == "ok":
                    logger.info(
                        "inference  session=%s  frame=%d  jpeg=%dB  fg=%d/%dpx  latency=%.1fms",
                        req.session_id, frame.frame_id, len(frame.image_data),
                        int(foreground.sum()), int(foreground.size), mask.latency_ms,
                    )
                else:
                    logger.error(
                        "frame error  session=%s  frame=%d  %s  latency=%.1fms",
                        req.session_id, frame.frame_id, mask.error_message, mask.latency_ms,
                    )
                yield pb.VideoResponse(
                    session_id=req.session_id,
                    stream_id=req.stream_id,
                    mask=mask,
                    is_final=True,
                )
                if req.is_eos:
                    return
