"""gRPC server bootstrap and CLI entry point."""
import argparse
import logging
import math
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import grpc
import mediapipe as mp

from mediapipe_video.config import AppConfig, load_config
from mediapipe_video.contract import pb
from mediapipe_video.log import setup_logging
from mediapipe_video.segmenter import Worker

logger = logging.getLogger(__name__)


def main():
    """MediaPipe SelfieSegmenter gRPC worker for the gateway's video.proto contract."""
    parser = argparse.ArgumentParser(description=main.__doc__)
    parser.add_argument("--config", type=Path, help="YAML config file (overridden by explicit CLI flags)")
    parser.add_argument("--addr", help="gRPC bind address")
    parser.add_argument("--model", type=Path, help="path to .tflite model file")
    parser.add_argument("--foreground-index", type=int, help="confidence_masks plane index (default: auto-detect)")
    parser.add_argument("--max-streams", type=int, help="max concurrent gRPC streams")
    parser.add_argument("--delegate", choices=("gpu", "cpu"), help="compute backend (default: gpu)")
    parser.add_argument("--result-timeout", type=float, help="seconds to wait for each LIVE_STREAM callback")
    parser.add_argument("--log-level", choices=("DEBUG", "INFO", "WARNING", "ERROR"), help="log verbosity")
    args = parser.parse_args()

    _DEFAULT_CONFIG = Path("etc/config.yaml")
    config_path = args.config or (_DEFAULT_CONFIG if _DEFAULT_CONFIG.is_file() else None)
    cfg = load_config(config_path) if config_path else AppConfig()

    # CLI flags override config file values when explicitly provided.
    if args.addr:
        cfg.server.addr = args.addr
    if args.model:
        cfg.mediapipe.model = args.model
    if args.foreground_index is not None:
        cfg.mediapipe.foreground_index = args.foreground_index
    if args.max_streams is not None:
        cfg.server.max_streams = args.max_streams
    if args.delegate:
        cfg.mediapipe.delegate = args.delegate
    if args.result_timeout is not None:
        cfg.mediapipe.result_timeout_secs = args.result_timeout
    if args.log_level:
        cfg.logging.level = args.log_level

    setup_logging(cfg.logging)

    if not cfg.mediapipe.model:
        parser.error("model path is required (set --model or config.mediapipe.model in YAML)")
    if not cfg.mediapipe.model.is_file():
        parser.error(f"model file not found: {cfg.mediapipe.model}")
    if cfg.server.max_streams <= 0:
        parser.error("max_streams must be positive")
    if not math.isfinite(cfg.mediapipe.result_timeout_secs) or cfg.mediapipe.result_timeout_secs <= 0:
        parser.error("result_timeout_secs must be finite and positive")

    try:
        worker = Worker(cfg.mediapipe, cfg.segmentation)
    except (ValueError, RuntimeError) as exc:
        hint = (
            " GPU requires a MediaPipe build with GPU support and a physical GPU exposed through EGL/OpenGL ES."
            if cfg.mediapipe.delegate == "gpu" else ""
        )
        parser.exit(1, f"Cannot initialize MediaPipe LIVE_STREAM ({cfg.mediapipe.delegate}): {exc}.{hint}\n")

    server = grpc.server(
        ThreadPoolExecutor(max_workers=cfg.server.max_streams),
        maximum_concurrent_rpcs=cfg.server.max_streams,
        options=(("grpc.max_receive_message_length", cfg.server.max_receive_message_bytes),),
    )
    server.add_generic_rpc_handlers((
        grpc.method_handlers_generic_handler("video.VideoStream", {
            "Segment": grpc.stream_stream_rpc_method_handler(
                worker.Segment,
                request_deserializer=pb.VideoRequest.FromString,
                response_serializer=pb.VideoResponse.SerializeToString,
            ),
        }),
    ))
    if not server.add_insecure_port(cfg.server.addr):
        raise RuntimeError(f"cannot bind {cfg.server.addr}")

    server.start()
    logger.info(
        "server ready  addr=%s  model=%s  mediapipe=%s  delegate=%s",
        cfg.server.addr, cfg.mediapipe.model, mp.__version__, cfg.mediapipe.delegate,
    )

    try:
        server.wait_for_termination()
    except KeyboardInterrupt:
        logger.info("shutting down  grace=%.1fs", cfg.server.shutdown_grace_secs)
        server.stop(cfg.server.shutdown_grace_secs).wait()
